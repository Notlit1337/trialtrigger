import requests
import re
import base64, string
from uuid import uuid4
import json, os, time
import yaml, random

BUILD_RE = re.compile(r'"BUILD_NUMBER"\s*:\s*"(\d+)"')
JSON_DUMPS = lambda obj: json.dumps(obj, separators=(',', ':'))

def get_build_number():
    try:
        r = requests.get("https://discord.com/login", timeout=5)
        m = BUILD_RE.search(r.text)
        return int(m.group(1)) if m else -1
    except requests.exceptions.RequestException as e:
        print(f"Error fetching build number: {e}")
        return -1

def load_config(path: str = "config.yaml") -> dict:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    except Exception as e:
        print(e)
        return {}
    
def get_proxy():
    with open("input/Proxies.txt", 'r') as f:
        proxies = "http://" + random.choice(f.read().split())
    return proxies

def get_cookies() -> str:
    r = requests.get("https://discord.com/app")
    return f'locale=en-US; __dcfduid={r.cookies.get("__dcfduid")}; __stripe_mid={str(uuid4())};__sdcfduid={r.cookies.get("__sdcfduid")}; __cfruid={r.cookies.get("__cfruid")}; _cfuvid={r.cookies.get("_cfuvid")}'

def get_random(amount: int = 10) -> str:
    return ''.join(random.choices(string.ascii_letters, k=amount))

def get_fingerprint() -> str:
    try:
        r = requests.get("https://discord.com/api/v9/experiments")
        return r.json().get("fingerprint", "")
    except Exception:
        return None

def generate_xsuper(ua: str, build: int, chrome: int) -> str:
    payload = {
        "os": "Windows", "browser": "Chrome", "device": "", "system_locale": "en-US",
        "has_client_mods": False,"browser_user_agent": ua,"browser_version": f"{chrome}.0.0.0", "os_version":"10", 
        "referrer": "", "referring_domain":"", "referrer_current":"https://discord.com/", "referring_domain_current":"discord.com", "release_channel": "stable",
        "client_build_number": build, "client_event_source": None, "client_launch_id":str(uuid4()),
        "launch_signature": str(uuid4()), "client_heartbeat_session_id": str(uuid4()),
        "client_app_state":"focused"
        }
    return base64.b64encode(JSON_DUMPS(payload).encode()).decode()
