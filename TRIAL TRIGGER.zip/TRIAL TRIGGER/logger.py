from colorama import Fore, init
from datetime import datetime
import threading
import time

init(autoreset=True)
__lock__ = threading.Lock()

class Colors:
    RESET = "\033[0m"
    red = "\033[38;5;196m"
    green = "\033[38;5;46m"
    yellow = "\033[38;5;226m"
    blue = "\033[38;5;21m"
    magenta = "\033[38;5;201m"
    cyan = "\033[38;5;51m"
    white = "\033[38;5;255m"

def log(message: str, level='ERROR', **kwargs):
    try:
        timestaps = datetime.now().strftime("%H:%M:%S")
        details = ''
        if kwargs:
            details += f" {Fore.LIGHTBLACK_EX}→{Fore.RESET} "
            details += f", ".join(
                f"{Colors.white}{key}: [{Colors.RESET}{Colors.cyan}{value}{Colors.RESET}{Colors.white}]{Colors.RESET}" for key, value in kwargs.items()
            )
            
        if level == 'INFO':
            output = Fore.LIGHTBLACK_EX + timestaps + Fore.RESET + ' ' + Fore.RESET + Fore.LIGHTMAGENTA_EX + str(level).upper() + Fore.RESET + Fore.LIGHTBLACK_EX + ' - ' + Fore.RESET + Colors.yellow + str(message) + Fore.RESET + details
            
        elif level == 'SUCCESS':   
            output = Fore.LIGHTBLACK_EX + timestaps + Fore.RESET + ' ' + Fore.RESET + Fore.LIGHTMAGENTA_EX + str(level).upper() + Fore.RESET + Fore.LIGHTBLACK_EX + ' - ' + Fore.RESET + Colors.green + str(message) + Fore.RESET + details
            
        elif level == 'ERROR':
            output = Fore.LIGHTBLACK_EX + timestaps + Fore.RESET + ' ' + Fore.RESET + Fore.LIGHTMAGENTA_EX + str(level).upper() + Fore.RESET + Fore.LIGHTBLACK_EX + ' - ' + Fore.RESET + Colors.red + str(message) + Fore.RESET + details

        elif level == 'PROCESS':
            output = Fore.LIGHTBLACK_EX + timestaps + Fore.RESET + ' ' + Fore.RESET + Fore.LIGHTMAGENTA_EX + str(level).upper() + Fore.RESET + Fore.LIGHTBLACK_EX + ' - ' + Fore.RESET + Colors.cyan + str(message) + Fore.RESET + details

        else:
            output = Fore.LIGHTBLACK_EX + timestaps + Fore.RESET + ' ' + Fore.RESET + Fore.LIGHTMAGENTA_EX + str(level).upper() + Fore.RESET + Fore.LIGHTBLACK_EX + ' - ' + Fore.RESET + Colors.yellow + str(message) + Fore.RESET + details

        with __lock__:
            print(output)
    except Exception as e:
        print(Fore.RED + str(e).capitalize() + Fore.RESET)
        time.sleep(2)
        return log(message, level, **kwargs)