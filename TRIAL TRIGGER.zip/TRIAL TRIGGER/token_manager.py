import os
import threading
from typing import List, Tuple

class TokenManager:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance.file_locks = {
                1: threading.Lock(),
                2: threading.Lock(),
                3: threading.Lock(),
            }
        return cls._instance

    def get_filepath(self) -> str:
        return "input/Tokens.txt"

    def get_tokens(self) -> Tuple[bool, List[str]]:
        file_path = self.get_filepath()
        lock = self.file_locks.get(1)

        if not lock or not os.path.isfile(file_path):
            return False, []

        with lock:
            try:
                with open(file_path, mode='r', encoding='utf-8') as f:
                    tokens = [line.strip() for line in f if line.strip()]
                return True, tokens
            except Exception as e:
                print(f"[get_tokens] Error: {e}")
                return False, []

    def write(self, item: str, filename: str) -> bool:
        lock = self.file_locks.get(3)
        if not lock:
            return False

        output_dir = os.path.dirname(filename)
        if output_dir and not os.path.exists(output_dir):
            os.makedirs(output_dir)

        with lock:
            try:
                with open(filename, 'a', encoding='utf-8') as f:
                    f.write(item + '\n')
                return True
            except Exception as e:
                print(f"[write] Error: {e}")
                return False

    def remove_token(self, token: str) -> bool:
        file_path = self.get_filepath()
        lock = self.file_locks.get(2)

        if not lock or not os.path.isfile(file_path):
            return False

        with lock:
            try:
                with open(file_path, mode="r", encoding="utf-8") as f:
                    lines = f.readlines()

                filtered_lines = [line for line in lines if token not in line.strip()]

                with open(file_path, mode="w", encoding="utf-8") as f:
                    f.writelines(filtered_lines)

                return True
            except Exception as e:
                print(f"[remove_token] Error: {e}")
                return False

tk = TokenManager()
